﻿using System;
using System.Linq;
using HtmlAgilityPack;
using System.IO;
using CsvHelper;
using System.Globalization;

namespace WebScrapper
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            string[] lines = System.IO.File.ReadAllLines(Directory.GetCurrentDirectory() + "../../../wkn.csv");
            bool flag = true;
            foreach (string line in lines)
            {
                string[] columns = line.Split(',');

                foreach (string column in columns)
                {
                    if (flag)
                        flag = false;
                    else
                    {
                        string[] wkn = column.Split(';');
                        if (wkn.Length > 1)
                        {
                            HtmlWeb Web = new HtmlWeb();
                            HtmlDocument Doc = Web.Load("https://www.comdirect.de/inf/search/general.html?IC_BYPASS=1&SEARCH_VALUE=" + wkn[1]);
                            var Description = wkn[0];
                            var Flat = GetString(Doc.DocumentNode.SelectNodes("//td[@data-label='Whg.']").ToList()[0].InnerText.ToString());
                            var Type = GetString(Doc.DocumentNode.SelectNodes("//td[@data-label='Typ']").ToList()[0].InnerText);
                            var Current = GetString(Doc.DocumentNode.SelectNodes("//td[@data-label='Aktuell']").ToList()[0].InnerText);
                            var DateTime = GetString(Doc.DocumentNode.SelectNodes("//td[@data-label='Datum Zeit']").ToList()[0].InnerText);
                            //var temp = Doc.DocumentNode.SelectNodes("//td[@class='table__column--top']").ToList();
                            //var StockEx = Doc.DocumentNode.SelectNodes("//td[@data-label='Borse']").ToList()[0].InnerText;
                            Console.WriteLine(Description + " " + Flat + " " + Type + " " + Current + " " + DateTime + " ");
                        }
                    }
                }
            }
        }

        public static string GetString(string text)
        {
            return text.Replace(" ", "").Replace("\n", "");
        }
    }

    public class WknCsv
    {
        public string Name;
        public string Wkn;
    }
}
