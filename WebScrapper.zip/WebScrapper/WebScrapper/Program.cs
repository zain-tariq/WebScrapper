﻿using System;
using System.Linq;
using HtmlAgilityPack;
using System.IO;
using CsvHelper;
using System.Globalization;
using Npgsql;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace WebScrapper
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            string[] lines = System.IO.File.ReadAllLines(Directory.GetCurrentDirectory() + "../../../wkn.csv");
            bool flag = true;

            string ConnectionString = String.Format("Server={0};Port={1};User Id={2};Password={3};Database={4};",
              "localhost", 5432, "postgres", 1234, "Stocks");
            NpgsqlConnection conn = new NpgsqlConnection(ConnectionString);
            conn.Open();

            List<WknCsv> list = new List<WknCsv>();

            foreach (string line in lines)
            {
                string[] wkn = line.Split(';');

                if (flag)
                        flag = false;
                else
                {
                    if (wkn.Length > 1)
                    {
                        HtmlWeb Web = new HtmlWeb();
                        HtmlDocument Doc = Web.Load("https://www.comdirect.de/inf/search/general.html?IC_BYPASS=1&SEARCH_VALUE=" + wkn[1]);
                        var Description = wkn[0];
                        var Items = Doc.DocumentNode.SelectNodes("//td[@class='table__column--top']").ToList();
                        var Flat = GetString(Items[1].InnerText);
                        var Type = GetString(Items[0].InnerText);
                        var Current = GetString(Doc.DocumentNode.SelectNodes("//td[@data-label='Aktuell']").ToList()[0].InnerText);
                        var Date = GetString(Items[2].InnerText);
                        ////var temp = Doc.DocumentNode.SelectNodes("//td[@class='table__column--top']").ToList();
                        var StockEx = GetString(Items[3].InnerText);
                        Console.WriteLine(Description + " " + Flat + " " + Type + " " + Current + " " + Date + " " + StockEx);
                        list.Add(new WknCsv(Description, wkn[1], Current, Type, Flat, StockEx, Date));
                    }
                }
            }

            AddToDatabase(list, conn);
            conn.Close();
        }

        public static void AddToDatabase(List<WknCsv> list, NpgsqlConnection conn)
        {
            foreach(WknCsv item in list)
            {
                try
                {
                    NpgsqlCommand cmd = new NpgsqlCommand("insert into stockinformation(wkn, type, description, flat, current, datetime, stockex) values(@wkn, @type, @description, @flat, @current, @datetime, @stockex)", conn);
                    cmd.Parameters.AddWithValue("@wkn", item.Wkn);
                    cmd.Parameters.AddWithValue("@type", item.Type);
                    cmd.Parameters.AddWithValue("@description", item.Description);
                    cmd.Parameters.AddWithValue("@flat", item.Flat);
                    cmd.Parameters.AddWithValue("@current", item.Current);
                    cmd.Parameters.AddWithValue("@stockex", item.StockEx);
                    cmd.Parameters.AddWithValue("@datetime", item.DateTime);
                    cmd.ExecuteNonQuery();
                    Console.WriteLine("Record entered Successfully");
                }
                catch (Exception e)
                {
                    Console.WriteLine("An error occured! " + e);
                }
            }
        }

        public static string GetString(string text)
        {
            return text.Replace(" ", "").Replace("\n", "").Replace("&#160;&#160;&#160;", " ");
        }
    }

    public struct WknCsv
    {
        public string Description;
        public string Wkn;
        public string Current;
        public string Type;
        public string Flat;
        public string StockEx;
        public string DateTime;

        public WknCsv(string description, string Wkn, string Current, string Type, string Flat, string StockEx, string DateTime)
        {
            this.Wkn = Wkn;
            this.Description = description;
            this.Current = Current;
            this.Type = Type;
            this.Flat = Flat;
            this.StockEx = StockEx;
            this.DateTime = DateTime;
        }
    }
}
